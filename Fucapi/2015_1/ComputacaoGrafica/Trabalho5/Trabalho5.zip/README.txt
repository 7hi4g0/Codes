Novas Features:

	Q - Alterna entre a camêra fixa e a camêra acima do avião
