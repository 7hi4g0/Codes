#!/usr/bin/env bash
mkdir -p ~/.vim/{autoload,ftplugin}
cp autoload/gocomplete.vim ~/.vim/autoload
cp ftplugin/go.vim ~/.vim/ftplugin
