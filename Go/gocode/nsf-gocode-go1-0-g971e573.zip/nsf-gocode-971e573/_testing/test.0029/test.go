package main

import . "fmt"

func main() {
	var a Formatter
	
}
