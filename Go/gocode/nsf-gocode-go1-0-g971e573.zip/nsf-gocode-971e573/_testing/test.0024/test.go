package main

type X struct {
	a,b,c int
}

func main() {
	var X *X
	X.
}
