package main

import "unsafe"

func main() {
	unsafe.
}
