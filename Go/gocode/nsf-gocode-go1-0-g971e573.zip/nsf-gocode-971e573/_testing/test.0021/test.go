package main

import "go/ast"

func main() {
	var test *ast.ImportSpec
	test.Name.
}
