package main

import "compress/zlib"

func main() {
	var b map[int]zlib.
}
