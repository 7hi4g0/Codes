package main

type Dummy struct {
	a, b, c int
}

func testEllipsis(dummies ...*Dummy) {
	for i, d := range dummies {
		x := dummies[0]
		
	}
}
