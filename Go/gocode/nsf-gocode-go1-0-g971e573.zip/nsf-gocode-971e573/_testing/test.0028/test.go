package main

type X int

func (x X) PowerOfTwo() int {
	return int(x * x)
}

func main() {
	a := X(56)
	i := a + 67
	j := ^i
	j.
}
