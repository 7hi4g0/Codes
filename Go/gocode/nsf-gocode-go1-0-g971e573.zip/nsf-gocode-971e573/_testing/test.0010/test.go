package main

import "go/ast"

func main() {
	var gd *ast.GenDecl
	v := gd.Specs[0].(*ast.ValueSpec)
	v.
}
