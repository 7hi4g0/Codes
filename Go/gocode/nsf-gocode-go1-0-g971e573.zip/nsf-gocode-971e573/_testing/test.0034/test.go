package main

import "image/png"

func test() {
	img, err := png.Decode(nil)
	img.
}
