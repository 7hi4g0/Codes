package main

import "syscall"

func main() {
	syscall.var
}
