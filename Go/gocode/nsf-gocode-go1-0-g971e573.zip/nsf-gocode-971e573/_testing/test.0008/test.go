package main

import "sync"

var hosts struct {
	sync.Mutex
	data map[string][]string
	time int64
	path string
}

hosts.

func main() {
}
