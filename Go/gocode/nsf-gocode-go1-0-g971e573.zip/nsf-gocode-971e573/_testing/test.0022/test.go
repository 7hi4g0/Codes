package main

import "os"

func main() {
	for key, value := range getMap() {
		
	}
}

func getMap() map[string]os.Error {
	// simply to trick type inference
	return nil
}
